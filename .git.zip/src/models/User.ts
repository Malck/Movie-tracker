// src/models/User.ts
import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please provide a name.'],
  },
  email: {
    type: String,
    required: [true, 'Please provide an email.'],
    unique: true, // Chaque email doit être unique
  },
  password: {
    type: String,
    required: [true, 'Please provide a password.'],
  },
}, {
  timestamps: true, // Ajoute automatiquement les champs createdAt et updatedAt
});

// On exporte le modèle. S'il existe déjà, on le réutilise, sinon on le crée.
// C'est une optimisation importante pour Next.js.
export default mongoose.models.User || mongoose.model('User', UserSchema);