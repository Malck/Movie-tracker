// src/app/page.tsx
import styles from './HomePage.module.css';
import MovieRow from '@/components/MovieRow';
import { getTrendingMovies, getTopRatedMovies, getNowPlayingMovies } from '@/lib/tmdb';

export default function HomePage() {
  return (
    <main className={styles.container}>
      <MovieRow title="Films du moment" fetcher={getTrendingMovies} />
      <MovieRow title="Les mieux notés" fetcher={getTopRatedMovies} />
      <MovieRow title="Nouveautés au cinéma" fetcher={getNowPlayingMovies} />
    </main>
  );
}