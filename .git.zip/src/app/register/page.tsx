// src/app/register/page.tsx
'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import styles from '../AuthForm.module.css'; // On va créer ce fichier juste après

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });

      if (res.ok) {
        router.push('/login'); // Redirige vers la page de connexion après succès
      } else {
        console.error("Erreur lors de l'inscription");
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className={styles.container}>
      <form onSubmit={handleSubmit} className={styles.form}>
        <h1>Inscription</h1>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nom" required />
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mot de passe" required />
        <button type="submit">S&apos;inscrire</button>
      </form>
    </div>
  );
}