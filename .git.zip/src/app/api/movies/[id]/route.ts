// src/app/api/movies/[id]/route.ts
import { getMovieDetails } from "@/lib/tmdb";
import { NextResponse } from "next/server";

interface Params {
  params: { id: string };
}

export async function GET(request: Request, { params }: Params) {
  try {
    const { id } = await params;
    const movieDetails = await getMovieDetails(id);
    return NextResponse.json(movieDetails);
  } catch (error) {
    return NextResponse.json({ message: "Erreur serveur." }, { status: 500 });
  }
}