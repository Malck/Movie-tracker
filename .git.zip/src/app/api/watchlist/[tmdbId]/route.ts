// src/app/api/watchlist/[tmdbId]/route.ts
import { getServerSession } from "next-auth/next";
import { authOptions } from "../../auth/[...nextauth]/route";
import dbConnect from "@/lib/dbConnect";
import Movie from "@/models/Movie";
import { NextResponse } from "next/server";

interface Params {
  params: { tmdbId: string };
}

// Fonction pour VÉRIFIER si un film est dans la watchlist
export async function GET(request: Request, { params }: Params) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ message: "Non autorisé" }, { status: 401 });
  }

  // LA CORRECTION EST ICI
  const { tmdbId } = await params;

  await dbConnect();
  const movie = await Movie.findOne({
    userId: session.user.id,
    tmdbId: tmdbId,
  });

  return NextResponse.json({ inWatchlist: !!movie, movieId: movie?._id });
}

// Fonction pour SUPPRIMER un film de la watchlist
export async function DELETE(request: Request, { params }: Params) {
    const session = await getServerSession(authOptions);
    if (!session || !session.user) {
        return NextResponse.json({ message: "Non autorisé" }, { status: 401 });
    }

    // ET LA CORRECTION EST ICI AUSSI
    const { tmdbId } = await params;

    await dbConnect();
    await Movie.findOneAndDelete({
        userId: session.user.id,
        tmdbId: tmdbId,
    });

    return NextResponse.json({ message: "Film supprimé" }, { status: 200 });
}