// src/app/api/watchlist/route.ts
import { getServerSession } from "next-auth/next";
import { authOptions } from "../auth/[...nextauth]/route";
import dbConnect from "@/lib/dbConnect";
import Movie from "@/models/Movie";
import { NextResponse } from "next/server";


export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ message: "Non autorisé" }, { status: 401 });
  }

  await dbConnect();

  try {
    const userId = session.user.id;
    const movies = await Movie.find({ userId: userId }).sort({ createdAt: -1 }); // On trie par date d'ajout
    return NextResponse.json(movies, { status: 200 });
  } catch (error) {
    return NextResponse.json({ message: "Erreur serveur." }, { status: 500 });
  }
}
export async function POST(request: Request) {
  // 1. Vérifier si l'utilisateur est connecté
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ message: "Non autorisé" }, { status: 401 });
  }

  await dbConnect();

  try {
    const { tmdbId, title, posterPath } = await request.json();
    const userId = session.user.id;

    // 2. Vérifier si le film n'est pas déjà dans la watchlist
    const existingMovie = await Movie.findOne({ userId, tmdbId });
    if (existingMovie) {
      return NextResponse.json({ message: "Ce film est déjà dans votre watchlist." }, { status: 409 }); // 409 Conflict
    }

    // 3. Créer le nouveau film en base de données
    await Movie.create({
      userId,
      tmdbId,
      title,
      posterPath,
    });

    return NextResponse.json({ message: "Film ajouté à la watchlist." }, { status: 201 });
  } catch (error) {
  console.error("--- ERREUR DÉTAILLÉE DANS /api/watchlist ---");
  console.error(error); // Affiche l'erreur complète et détaillée

  const errorMessage = error instanceof Error ? error.message : 'Une erreur inconnue est survenue';
  return NextResponse.json(
    { error: `Erreur côté serveur : ${errorMessage}` },
    { status: 500 }
  );
}
}

export async function PUT(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ message: "Non autorisé" }, { status: 401 });
  }

  await dbConnect();

  try {
    const { movieId, status } = await request.json(); // On reçoit l'ID du film et le nouveau statut
    const userId = session.user.id;

    await Movie.findOneAndUpdate(
      { _id: movieId, userId: userId }, // On s'assure que le film appartient bien à l'utilisateur
      { status: status }
    );

    return NextResponse.json({ message: "Statut du film mis à jour." }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ message: "Erreur serveur." }, { status: 500 });
  }
}

// AJOUTE CETTE FONCTION POUR LA SUPPRESSION
export async function DELETE(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ message: "Non autorisé" }, { status: 401 });
  }

  await dbConnect();

  try {
    const { movieId } = await request.json(); // On reçoit l'ID du film à supprimer
    const userId = session.user.id;

    await Movie.findOneAndDelete({ _id: movieId, userId: userId });

    return NextResponse.json({ message: "Film supprimé de la watchlist." }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ message: "Erreur serveur." }, { status: 500 });
  }
}