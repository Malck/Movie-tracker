// src/app/api/auth/[...nextauth]/route.ts
import NextAuth from 'next-auth';
import type { AuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import dbConnect from '@/lib/dbConnect';
import User from '@/models/User';
import bcrypt from 'bcryptjs';

export const authOptions: AuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: "Email", type: "email" },
        password: {  label: "Password", type: "password" }
      },
      async authorize(credentials) {
        await dbConnect();

        if (!credentials) {
          return null;
        }

        const user = await User.findOne({ email: credentials.email });

        if (user && bcrypt.compareSync(credentials.password, user.password)) {
          return { id: user._id.toString(), name: user.name, email: user.email };
        } else {
          return null;
        }
      }
    })
  ],
  session: {
    strategy: 'jwt' as const,
  },
  secret: process.env.NEXTAUTH_SECRET,
  pages: {
    signIn: '/login',
  },
  // LA MODIFICATION EST ICI : on ajoute ce bloc pour enrichir la session
  callbacks: {
    async jwt({ token, user }) {
      // Si l'objet `user` existe (uniquement au moment de la connexion),
      // on copie son ID dans le jeton (token).
      if (user) {
        token.id = user.id;
      }
      return token;
    },
    async session({ session, token }) {
      // À chaque fois qu'une session est lue, on copie l'ID du jeton
      // dans l'objet `session.user` pour qu'il soit accessible partout.
      if (session.user) {
        session.user.id = token.id as string;
      }
      return session;
    },
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };