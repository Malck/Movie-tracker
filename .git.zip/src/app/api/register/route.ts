// src/app/api/register/route.ts
import dbConnect from "@/lib/dbConnect";
import User from "@/models/User";
import { NextResponse } from "next/server";
import bcrypt from 'bcryptjs';

export async function POST(request: Request) {
  await dbConnect();

  try {
    const { name, email, password } = await request.json();

    // On hache le mot de passe avant de le sauvegarder
    const hashedPassword = await bcrypt.hash(password, 10);

    await User.create({
      name,
      email,
      password: hashedPassword,
    });

    return NextResponse.json({ message: "Utilisateur créé." }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ message: "Erreur lors de la création de l'utilisateur." }, { status: 500 });
  }
}