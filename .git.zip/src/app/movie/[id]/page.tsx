// src/app/movie/[id]/page.tsx
'use client';

import { useState, useEffect, use } from 'react';
// On n'importe PAS getMovieDetails ici, car la page ne l'appelle plus directement
import Image from 'next/image';
import styles from './DetailPage.module.css';
import BackButton from '@/components/BackButton';
import AddToWatchlistButton from '@/components/AddToWatchlistButton';
import VideoModal from '@/components/VideoModal';
import DetailSkeleton from '@/components/DetailSkeleton';

interface Video {
  key: string;
  site: string;
  type: string;
}

interface MovieDetails {
  id: number;
  title: string;
  overview: string;
  poster_path: string;
  backdrop_path: string;
  release_date: string;
  vote_average: number;
  videos: {
    results: Video[];
  };
}

export default function MovieDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params);
  const [movie, setMovie] = useState<MovieDetails | null>(null);
  const [trailerKey, setTrailerKey] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const imageBaseUrl = 'https://image.tmdb.org/t/p/w500';

  useEffect(() => {
    const fetchDetails = async () => {
      try {
        // === LA CORRECTION EST ICI ===
        // On appelle notre propre API, qui est sécurisée
        const response = await fetch(`/api/movies/${resolvedParams.id}`);
        if (!response.ok) {
          throw new Error('Échec de la récupération des données depuis notre API');
        }
        const movieData = await response.json();
        setMovie(movieData);

        const trailer = movieData.videos?.results.find(
          (video: Video) => video.site === 'YouTube' && video.type === 'Trailer'
        );
        if (trailer) {
          setTrailerKey(trailer.key);
        }
      } catch (error) {
        console.error(error);
        // On pourrait mettre en place un état d'erreur pour l'afficher à l'utilisateur
      }
    };
    fetchDetails();
  }, [resolvedParams.id]);

  if (!movie) {
    return <DetailSkeleton />;
  }

  return (
    <>
      <div className={styles.pageContainer}>
        <div className={styles.backdrop}>
          <Image
  src={`https://image.tmdb.org/t/p/w1280${movie.backdrop_path || movie.poster_path}`}
  alt={`${movie.title} backdrop`}
  fill  // 'layout="fill"' devient 'fill'
  style={{ objectFit: 'cover' }} // 'objectFit' va dans la prop 'style'
  className={styles.backdropImage}
  priority // On ajoute 'priority' pour charger cette image importante plus vite
/>
        </div>
        <main className={styles.mainContent}>
          <div className={styles.buttonContainer}><BackButton /></div>
          <div className={styles.content}>
            <div className={styles.poster}>
              <Image src={`${imageBaseUrl}${movie.poster_path}`} alt={movie.title} width={300} height={450} className={styles.posterImage} />
            </div>
            <div className={styles.info}>
              <h1>{movie.title}</h1>
              <p className={styles.tagline}>
                Sorti le: {new Date(movie.release_date).toLocaleDateString('fr-FR')} | Note: {movie.vote_average.toFixed(1)} / 10
              </p>
              <h2>Synopsis</h2>
              <p>{movie.overview}</p>
              {trailerKey && (
                <button onClick={() => setIsModalOpen(true)} style={{ marginTop: '1rem', padding: '0.75rem 1.5rem', backgroundColor: '#c53030', color: 'white', borderRadius: '0.25rem', border: 'none', cursor: 'pointer' }}>
                  Voir la bande-annonce
                </button>
              )}
              <AddToWatchlistButton tmdbId={movie.id} title={movie.title} posterPath={movie.poster_path} />
            </div>
          </div>
        </main>
      </div>
      {isModalOpen && trailerKey && (
        <VideoModal videoKey={trailerKey} onClose={() => setIsModalOpen(false)} />
      )}
    </>
  );
}