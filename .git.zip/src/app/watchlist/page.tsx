// src/app/watchlist/page.tsx
'use client';

import { useState, useEffect } from 'react';
import styles from '../HomePage.module.css';
import WatchlistMovieCard from '@/components/WatchlistMovieCard';

interface Movie {
  _id: string;
  tmdbId: number;
  title: string;
  posterPath: string;
  status: 'À voir' | 'Vu';
}

export default function WatchlistPage() {
  const [watchlist, setWatchlist] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWatchlist = async () => {
      const res = await fetch('/api/watchlist');
      if (res.ok) {
        const data = await res.json();
        setWatchlist(data);
      }
      setLoading(false);
    };
    fetchWatchlist();
  }, []);

  const handleDeleteMovie = (id: string) => {
    setWatchlist(currentWatchlist => currentWatchlist.filter(movie => movie._id !== id));
  };

  const handleStatusChange = (id: string, newStatus: 'Vu') => {
    setWatchlist(currentWatchlist => 
      currentWatchlist.map(movie => 
        movie._id === id ? { ...movie, status: newStatus } : movie
      )
    );
  };

  if (loading) {
    return <main className={styles.container}><p>Chargement de votre watchlist...</p></main>;
  }

  return (
    <main className={styles.container}>
      <h1 className={styles.title}>Ma Watchlist</h1>
      {watchlist.length > 0 ? (
        <div className={styles.movieGrid}>
          {watchlist.map((movie) => (
            <WatchlistMovieCard 
              key={movie._id}
              movie={movie}
              onDelete={handleDeleteMovie}
              onStatusChange={handleStatusChange}
            />
          ))}
        </div>
      ) : (
        <p>Votre watchlist est vide pour le moment.</p>
      )}
    </main>
  );
}