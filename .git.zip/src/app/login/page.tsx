// src/app/login/page.tsx
'use client';

import { useState } from "react";
import { signIn } from 'next-auth/react';
import { useRouter } from "next/navigation";
import styles from '../AuthForm.module.css';
import Link from 'next/link'; // 1. Importer Link

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(''); // Ajout pour afficher les erreurs
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); // Réinitialiser l'erreur
    try {
      const result = await signIn('credentials', {
        redirect: false,
        email,
        password,
      });

      if (result?.ok) {
        router.push('/');
        router.refresh(); // Force un rafraîchissement pour mettre à jour le header
      } else {
        setError("Email ou mot de passe incorrect."); // Message d'erreur
      }
    } catch (error) {
      setError("Une erreur est survenue.");
    }
  };

  return (
    <div className={styles.container}>
      <form onSubmit={handleSubmit} className={styles.form}>
        <h1>Connexion</h1>
        {error && <p className={styles.error}>{error}</p>}
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mot de passe" required />
        <button type="submit">Se connecter</button>

        {/* 2. AJOUTER CE BLOC DE CODE */}
        <p className={styles.linkText}>
          Pas encore de compte ? <Link href="/register" className={styles.link}>Inscrivez-vous</Link>
        </p>
      </form>
    </div>
  );
}