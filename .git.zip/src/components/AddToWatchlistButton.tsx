// src/components/AddToWatchlistButton.tsx
'use client';
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface AddToWatchlistButtonProps {
  tmdbId: number;
  title: string;
  posterPath: string;
}

export default function AddToWatchlistButton({ tmdbId, title, posterPath }: AddToWatchlistButtonProps) {
  const { data: session, status: sessionStatus } = useSession();
  const [inWatchlist, setInWatchlist] = useState(false);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    // Si l'utilisateur est connecté, on vérifie le statut du film
    if (sessionStatus === 'authenticated') {
      const checkStatus = async () => {
        const res = await fetch(`/api/watchlist/${tmdbId}`);
        if (res.ok) {
          const data = await res.json();
          setInWatchlist(data.inWatchlist);
        }
        setLoading(false);
      };
      checkStatus();
    }
    if (sessionStatus === 'unauthenticated') {
      setLoading(false);
    }
  }, [sessionStatus, tmdbId]); // Se redéclenche si la session ou l'ID du film change

  const handleClick = async () => {
    if (!session) {
      router.push('/login'); // Redirige vers la connexion si l'utilisateur n'est pas connecté
      return;
    }

    if (inWatchlist) { // Si le film est déjà là, on le supprime
      await fetch(`/api/watchlist/${tmdbId}`, { method: 'DELETE' });
      setInWatchlist(false);
    } else { // Sinon, on l'ajoute
      await fetch('/api/watchlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tmdbId, title, posterPath }),
      });
      setInWatchlist(true);
    }
  };

  // On n'affiche rien pendant le chargement initial
  if (loading || sessionStatus === 'loading') {
    return <div style={{ height: '48px' }}></div>; // Placeholder
  }
  
  return (
    <div>
      <button 
        onClick={handleClick} 
        style={{ marginTop: '1rem', padding: '0.75rem 1.5rem', backgroundColor: inWatchlist ? '#c53030' : '#3182ce', color: 'white', borderRadius: '0.25rem', border: 'none', cursor: 'pointer' }}
      >
        {inWatchlist ? 'Retirer de la watchlist' : 'Ajouter à ma watchlist'}
      </button>
    </div>
  );
}