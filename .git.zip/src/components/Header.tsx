// src/components/Header.tsx
'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import styles from './Header.module.css';
import { FiSearch, FiX } from 'react-icons/fi';
import { useSession, signOut } from 'next-auth/react';

export default function Header() {
  const { data: session } = useSession();
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const [query, setQuery] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const router = useRouter();
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query) {
      router.push(`/search?query=${query}`);
      setIsSearchVisible(false);
      setQuery('');
    }
  };
  
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [dropdownRef]);


  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link href="/" className={styles.logo}>
          Movie Tracker
        </Link>
        <div className={styles.navLinks}>
          
          {/* === LOGIQUE DE LA BARRE DE RECHERCHE (REMISE ICI) === */}
          {!isSearchVisible && (
            <button 
              onClick={() => setIsSearchVisible(true)} 
              className={styles.searchIcon}
            >
              <FiSearch size={24} />
            </button>
          )}

          {isSearchVisible && (
            <form onSubmit={handleSearch} className={styles.searchForm}>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Rechercher un film..."
                className={styles.searchInput}
                autoFocus
              />
              <button 
                type="button" 
                onClick={() => setIsSearchVisible(false)} 
                className={styles.searchIcon}
              >
                <FiX size={24} />
              </button>
            </form>
          )}

          {/* === LOGIQUE DU PROFIL / CONNEXION === */}
          {session ? (
            <div className={styles.profileContainer} ref={dropdownRef}>
              <div 
                className={styles.avatar} 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                {session.user?.name?.charAt(0)}
              </div>

              {isDropdownOpen && (
                <div className={styles.dropdown}>
                  <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid #4a5568' }}>
                    <div style={{ fontWeight: 'bold' }}>{session.user?.name}</div>
                    <div style={{ fontSize: '0.8rem', color: '#a0aec0' }}>{session.user?.email}</div>
                  </div>
                  <Link href="/watchlist">Ma Watchlist</Link>
                  <button onClick={() => { setIsDropdownOpen(false); signOut({ callbackUrl: '/' }); }}>
                    Déconnexion
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link href="/login" className={styles.link}>Connexion</Link>
              <Link href="/register" className={styles.link}>Inscription</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}