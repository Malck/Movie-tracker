// src/components/WatchlistMovieCard.tsx
'use client';

import Link from 'next/link';
import Image from 'next/image';
import styles from './WatchlistMovieCard.module.css';

interface Movie {
  _id: string;
  tmdbId: number;
  title: string;
  posterPath: string;
  status: 'À voir' | 'Vu';
}

interface WatchlistMovieCardProps {
  movie: Movie;
  onDelete: (id: string) => void;
  onStatusChange: (id: string, status: 'Vu') => void;
}

export default function WatchlistMovieCard({ movie, onDelete, onStatusChange }: WatchlistMovieCardProps) {
  const handleDelete = async () => {
    await fetch('/api/watchlist', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ movieId: movie._id }),
    });
    onDelete(movie._id); // On prévient la page parente de supprimer le film de l'affichage
  };

  const handleMarkAsWatched = async () => {
    await fetch('/api/watchlist', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ movieId: movie._id, status: 'Vu' }),
    });
    onStatusChange(movie._id, 'Vu'); // On prévient la page parente de mettre à jour le statut
  };

  return (
    <div className={styles.card}>
      <Link href={`/movie/${movie.tmdbId}`}>
        <Image
          src={`https://image.tmdb.org/t/p/w500${movie.posterPath}`}
          alt={movie.title}
          width={500}
          height={750}
          className={styles.image}
        />
        {movie.status === 'Vu' && <div className={styles.watchedOverlay}>VU</div>}
      </Link>
      <div className={styles.actions}>
        {movie.status === 'À voir' && (
          <button onClick={handleMarkAsWatched}>Marquer comme vu</button>
        )}
        <button onClick={handleDelete} className={styles.deleteButton}>Supprimer</button>
      </div>
    </div>
  );
}